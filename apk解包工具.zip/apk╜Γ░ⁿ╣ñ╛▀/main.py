# -*- coding:UTF-8 -*-
#! /usr/bin/python
'''
Created on 2016年7月30日
@author: QQ:281431280
'''
import random
import time
from script.utils.path import path
from script.utils.apktool import apktool
def test():
    client_media_id = str(int(time.time() * 1000)) + str(random.random())[:5].replace('.', '')
    print client_media_id
def main():
    apk = "%s111.apk" % path.get_instance().get_base_path()  #名字要一样
    outapk = "%s111.apk" % path.get_instance().get_base_path()
    # print apktool.zipalign(apk, outapk)
    dec_dir = "%s111" % path.get_instance().get_base_path()
    print apktool.decompile_apk(apk, dec_dir)
    #apk = "%stdd_not_sign.apk" % (path.get_instance().get_base_path())
    # print apktool.compile_apk(dec_dir, apk)
    # print apktool.remove_meta_info(apk)
    # print apktool.jarsigner(apk,"e:/work/buildToos/keystore/my.keystore")
    # print apktool.zipalign(apk, outapk)
    pass
if __name__ == '__main__':
    main()
    # test()