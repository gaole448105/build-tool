# -*- coding:UTF-8 -*-
#! /usr/bin/python
'''
Created on 2016年8月06日
@author: QQ:281431280
'''
import os
from script.utils.path import path

class apktool(object):
    def __init__(self):
        pass
    @staticmethod
    def decompile_apk(apk, dec_dir):
        os.chdir(path.get_instance().get_java_path())
        print "java -jar %sapktool.jar d %s -f -o %s" % (path.get_instance().get_tools_path(), apk, dec_dir)
        ret = os.system("java -jar %sapktool.jar d %s -f -o %s" % (path.get_instance().get_tools_path(), apk, dec_dir))
        return ret == 0 and True or False 
    @staticmethod
    def compile_apk(dec_dir, apk):
        os.chdir(path.get_instance().get_java_path())
        print "java -jar %sapktool.jar b %s -f -o %s" % (path.get_instance().get_tools_path(), dec_dir, apk)
        ret = os.system("java -jar %sapktool.jar b %s -f -o %s" % (path.get_instance().get_tools_path(), dec_dir, apk))
        return ret == 0 and True or False
    @staticmethod
    def remove_meta_info(apk):
        ret = True
        os.chdir(path.get_instance().get_tools_path())
        data = os.popen("aapt list %s" % apk).read()
        for i in data.split("\n"):
            if i.find("META-INF") == 0:
                re = os.system("aapt remove %s %s" % (apk, i))
                ret = re == 0 and True or False
        return ret
    @staticmethod
    def jarsigner(apk, keystore="./keystore/my.keystore", storepass="123456", keypass="123456", alias="mykey"):
        os.chdir(path.get_instance().get_java_path())
        print "jarsigner -keystore %s -storepass %s -keypass %s %s %s -sigalg SHA1withRSA -digestalg SHA1" % (keystore, storepass, keypass, apk, alias)
        ret = os.system("jarsigner -keystore %s -storepass %s -keypass %s %s %s -sigalg SHA1withRSA -digestalg SHA1" % (keystore, storepass, keypass, apk, alias))
        return ret == 0 and True or False
    @staticmethod
    def zipalign(apk, outapk):
        os.chdir(path.get_instance().get_tools_path())
        print "zipalign -f -v 4 %s %s" % (apk, outapk)
        ret = os.system("zipalign -f -v 4 %s %s" % (apk, outapk))
        return ret == 0 and True or False
if __name__ == '__main__':
    
    pass
