# -*- coding:UTF-8 -*-
#! /usr/bin/python
'''
Created on 2016年8月06日
@author: QQ:281431280
'''
import os
import threading


class path(object):
    _script_path = None
    instance = None
    mutex = threading.Lock()
    @staticmethod
    def get_instance():
        if(path.instance == None):
            path.mutex.acquire()
            if(path.instance == None):
                path.instance = path()
            path.mutex.release()
        return path.instance
    def __init__(self):
        self._script_path = os.getcwd()
        pass
    def get_base_path(self):
        return "%s/" % (self._script_path)
    def get_tools_path(self):
        return "%stools/" % (self.get_base_path())
    def get_java_path(self):
        return "%sjre/bin/" % (self.get_tools_path())
if __name__ == '__main__':
    pass    