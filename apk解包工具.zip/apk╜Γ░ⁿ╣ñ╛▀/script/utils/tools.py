'''
Created on 2016��7��30��

@author: Administrator
'''

class tools(object):
    '''
    classdocs
    '''
    def __init__(self, params):
        '''
        Constructor
        '''
    @staticmethod
    def getAllChannels():
        pass