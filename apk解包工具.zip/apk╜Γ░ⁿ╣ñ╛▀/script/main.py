# -*- coding:UTF-8 -*-
#! /usr/bin/python
'''
Created on 2016年7月30日
@author: QQ:281431280
'''
from script.utils.path import path
from script.utils.apktool import apktool
def main():
    apk = "%s123.apk" % path.get_instance().get_base_path()
    outapk = "%sout.apk" % path.get_instance().get_base_path()
    # print apktool.zipalign(apk, outapk)
    dec_dir = "%s123" % path.get_instance().get_base_path()
    print apktool.decompile_apk(apk, dec_dir)
    # apk = "%s456.apk" % (path.get_instance().get_base_path())
    print apktool.compile_apk(dec_dir, apk)
    print apktool.remove_meta_info(apk)
    # print apktool.jarsigner(apk,"e:/wk/buildToos/keystore/my.keystore")
    # print apktool.zipalign(apk, outapk)
    pass
if __name__ == '__main__':
    main()