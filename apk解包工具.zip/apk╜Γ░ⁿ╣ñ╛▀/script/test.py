# -*- coding:UTF-8 -*-
#! /usr/bin/python
'''
Created on 2016年7月30日
@author: QQ:281431280
'''
import os
if __name__ == '__main__':
    script_path = os.getcwd()
    base_path = "%s/../" %(script_path)
    java_path = base_path+"/tools/jre/bin/"
    tools_path = base_path+"tools/"
    keystore_path = base_path+"keystore/my.keystore"
    signapk_path = base_path + "sdk.apk"
    alizgnapk_path = base_path + "sdk_alizgn.apk"
    os.chdir(java_path)
    print os.system("java -version")
    print os.system("java -jar %sapktool.jar d %sSDKDemo.apk -f -o %s/temp" %(tools_path,base_path,base_path))
    print os.system("java -jar %sapktool.jar b %stemp -f -o %ssdk.apk" % (tools_path,base_path,base_path))
    os.chdir(tools_path)
    cmd = "aapt list %s" % (signapk_path)
    print cmd
    data =  os.popen(cmd).readlines()
    for i in data:
        if i.find("META_INF") == 0:
            rmcmd = "aapt remove %s %s" (signapk_path,i)
            print os.system(cmd)
    os.chdir(java_path)
    cmd = "jarsigner -keystore %s -storepass %s -keypass %s %s %s -sigalg SHA1withRSA -digestalg SHA1" % (keystore_path,"123456","123456",signapk_path,"mykey");
    print cmd
    print os.system(cmd)
    print script_path
    os.chdir(tools_path)
    cmd = "zipalign -f -v 4 %s %s" %(signapk_path,alizgnapk_path)
    print os.system(cmd)
    pass